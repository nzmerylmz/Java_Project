package Gun40.Ornek4;

public interface IFood {
    void taste();
    double ucret();
}
